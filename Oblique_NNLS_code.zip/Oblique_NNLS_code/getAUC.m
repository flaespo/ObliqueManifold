function [auc,best_idx] = getAUC(F0,t0,F1,t1,F2,t2,F3,t3)


if nargin ==8
alg1.t = t0;   alg1.f = F0;
alg2.t = t1;   alg2.f = F1;
alg3.t = t2;   alg3.f = F2;
alg4.t = t3;   alg4.f = F3;
algs   = {alg1, alg2, alg3, alg4};
names  = {'EMU+proj','SMU+proj','RMU','RCG'};
 
% Set common time limit
Tmax = max([max(t0) max(t1) max(t2) max(t3)]); 

% Compute AUC and prepare for plotting
auc      = zeros(4, 1);
t_common = linspace(0, Tmax, 100); % Common time points for interpolation
F_interp = zeros(4, length(t_common)); % Store interpolated F values

for i = 1:4
    % Interpolate f(t) at common time points
    if max(algs{i}.t) >= Tmax
        F_interp(i, :) = interp1(algs{i}.t, algs{i}.f, t_common, 'linear', 'extrap');
    else
        % If data doesn't reach T_max, extrapolate cautiously
        F_interp(i, :) = interp1(algs{i}.t, algs{i}.f, t_common, 'linear', algs{i}.f(end));
    end
  
    % Compute AUC using trapezoidal rule
    auc(i) = trapz(t_common, F_interp(i, :));
end

% Display AUC results
results = table(names', auc, 'VariableNames', {'Algorithm', 'AUC'});
disp('AUC (smaller is better):');
disp(results);

% Highlight the best algorithm
[min_auc, best_idx] = min(auc);
fprintf('\nBest Algo: %s with AUC = %.4f\n', names{best_idx}, min_auc);


elseif nargin == 6


alg1.t = t0;   alg1.f = F0;
alg2.t = t1;   alg2.f = F1;
alg3.t = t2;   alg3.f = F2;
algs   = {alg1, alg2, alg3};
names  = {'EMU+proj','RMU','RCG'};
 
% Set common time limit
Tmax = max([max(t0) max(t1) max(t2)]); 

% Compute AUC and prepare for plotting
auc      = zeros(3, 1);
t_common = linspace(0, Tmax, 100); % Common time points for interpolation
F_interp = zeros(3, length(t_common)); % Store interpolated F values

for i = 1:3
    % Interpolate f(t) at common time points
    if max(algs{i}.t) >= Tmax
        F_interp(i, :) = interp1(algs{i}.t, algs{i}.f, t_common, 'linear', 'extrap');
    else
        % If data doesn't reach T_max, extrapolate cautiously
        F_interp(i, :) = interp1(algs{i}.t, algs{i}.f, t_common, 'linear', algs{i}.f(end));
    end
  
    % Compute AUC using trapezoidal rule
    auc(i) = trapz(t_common, F_interp(i, :));
end

% Display AUC results
results = table(names', auc, 'VariableNames', {'Algorithm', 'AUC'});
disp('AUC (smaller is better):');
disp(results);

% Highlight the best algorithm
[min_auc, best_idx] = min(auc);
fprintf('\nBest Algo: %s with AUC = %.4f\n', names{best_idx}, min_auc);


end
end