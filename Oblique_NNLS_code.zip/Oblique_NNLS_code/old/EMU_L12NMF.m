function [W,H,F,t,ER] = EMU_L12NMF(X,W,H,lambda,Iter)

cputime0 = cputime; 

%%
n            = size(X,2);
%timeSubtract = 0; % total time to be subtracted on computing function value
F            = nan(Iter,1); % objective function value
%T            = F; % time stamp
%timeStart    = tic;
[m,r]        = size(W);
n            = size(H,2);




F(1)     = objective_func(X,W,H,lambda);
ER(1) = (norm(X-W*H,'fro')^2)/(norm(X,'fro')^2);
t(1) = cputime - cputime0; 

%% main loop
for k = 2 : (Iter+1)
    %%update H

    Wt = W';
    WtX = Wt*X;
    WtW = Wt*W;
    WtWH = WtW*H;

    % H_12 = (sqrt(H)).^(-1);

    H_12 = sqrt(H);
    H_12 = (sum(sum(H_12)))*ones(r,n);
    den = WtWH+(lambda/2)*H_12+eps;
    H = H.* (WtX./den);
    for i = 1:n
        H(:,i) = H(:,i)/(sum(H(:,i))+eps);
    end

    %% update W
    % Ht = H';
    % XHt = X*Ht;
    % HHt = H*Ht;
    % WHHt = W*HHt;
    % 
    % XHt_WHHt = XHt./(WHHt+eps);
    % W = W.*XHt_WHHt;



    %% Computing function values
    F(k)     = objective_func(X,W,H,lambda);
    ER(k) = (norm(X-W*H,'fro')^2)/(norm(X,'fro')^2);
    t(k) = cputime - cputime0; 

end%endFOR
end%EOF