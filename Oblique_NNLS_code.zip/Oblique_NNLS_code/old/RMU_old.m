% minimize (1/2)||M-WH||_F^2 + lambda || H ||_{1/2}^{1/2} 
%        s.t.   H >=0,   H sum-to-1
% using Riemannain Multiplicative Update
function [H,F,t,f,g] = RMU_old(M,W,Hini,lambda, maxiter)
WtM  = W'*M; % constant outside loop
WtW  = W'*W; % constant outside loop
lam2 = lambda/2; 

A         = sqrt(Hini);
totalTime = 0; % Cumulative time
for k = 1 : maxiter
iterStart = tic; % Start timer for this iteration

    %A          = sqrt(H);
    signA      = sign(A);
    diag_vec_1 = diag(A'*(WtM.*A));
    diag_mat_1 = diag(diag_vec_1);
    WtWH       = WtW*(A.*A); % H = AdotA;
    grad_pos   = 2*(WtWH).*A+lam2*signA+2*A*diag_mat_1;

    diag_vec_2 = diag(A'*(WtWH));
    diag_mat_2 = diag(diag_vec_2);
    diag_vec_3 = diag(A'*signA);
    diag_mat_3 = diag(diag_vec_3);
    grad_neg   = 2*(WtM.*A)+2*A*diag_mat_2+lam2*A*diag_mat_3;

    grad       = grad_pos-grad_neg;
    alpha      = A./(grad_pos+eps);

    Z          = -alpha .* grad; %argument for retraction

    %define the retraction
    A_Z        = A+Z;
    diag_vec   = diag(A_Z'*A_Z);
    diag_mat   = diag(diag_vec);
    fac        = (sqrt(diag_mat)+eps)^(-1);
    A          = A_Z*fac; %update with retraction
    %H          = A.*A; % update H

totalTime = totalTime + toc(iterStart); % Update cumulative time
t(k)      = totalTime; % Record time up to this iteration      
[F(k),f(k),g(k)] = objective_func(M, W, A.*A,lambda); % not timed
end%end for loop

% output H
H = A.*A;
end%EOF