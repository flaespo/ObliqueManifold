clear;close all;clc
%% gen data
m = 20;
n = 500;
r = 3;
[W_exact,H_exact] = factors_generation([m n],r,0,0.7,3);
M                 = W_exact*H_exact + 0.01*rand(m,n);
%% initialization
[W,Hini] = NNDSVD(M,r,0);
lam = (1/2)*norm(M-W*Hini,'fro')^2 / sum(sum(sqrt(Hini)))
%% Run algo
[H0,F0,t0] = RMU_old(M,W,Hini,lam, 10);
checkFeasibility(H0)

[H1,F1,t1] = RMU     (M,W,Hini,lam, 10);
checkFeasibility(H1)
%% Plot
figure
Fmin = min([min(F0) min(F1)]);
subplot(121)
semilogy(F0-Fmin,'k-x','linewidth',3),hold on,
semilogy(F1-Fmin,'b-x','linewidth',2)
grid on,axis tight
lgd = legend('EMU+proj','RMU'); 
xlabel('Iter','Interpreter','latex')
ylabel('$F - F_\textrm{min}$','Interpreter','latex')
set(gca,'FontSize',16)

subplot(122)
semilogy(t0,F0-Fmin+eps,'k-x','linewidth',3),hold on,
semilogy(t1,F1-Fmin+eps,'b-x','linewidth',2)
grid on,axis tight
xlabel('Time (sec)','Interpreter','latex')
ylabel('$F - F_\textrm{min}$','Interpreter','latex')
set(gca,'FontSize',16)