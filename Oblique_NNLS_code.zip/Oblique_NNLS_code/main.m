clear;close all;clc
%% gen data
m = 50;
n = 200;
r = 5;
sparsity_level_H = 0.5;
[W_exact,H_exact] = factors_generation([m n],r,0,sparsity_level_H,3);
M                 = W_exact*H_exact + 0.1*rand(m,n);
%% initialization
[~,Hini] = NNDSVD(M,r,0); % Hini not necessarily colum-normalized
lam      = 0.5*norm(M-W_exact*Hini,'fro')^2 / sum(sum(sqrt(Hini)))
%% Run algo
maxiter = 1e6; % max number of iteration
maxtime = 5;   % max run time
[H0,F0,t0] = EMU_proj    (M,W_exact,Hini,lam, maxiter,maxtime);
[H1,F1,t1] = sparse_mu_l1(M,W_exact,Hini,lam, maxiter,maxtime);
[H2,F2,t2] = RMU         (M,W_exact,Hini,lam, maxiter,maxtime);
[H3,F3,t3] = RCG         (M,W_exact,Hini,lam, maxiter,maxtime);
%% Plot
figure('Position', get(0, 'ScreenSize'));
Fmin = min([min(F0) min(F1) min(F2) min(F3)]);
subplot(121)
semilogy(F0-Fmin+eps,'k-x','linewidth',5),hold on,
semilogy(F1-Fmin+eps,'b:x','linewidth',2)
semilogy(F2-Fmin+eps,'c-x','linewidth',2)
semilogy(F3-Fmin+eps,'m-x','linewidth',2)
grid on,axis tight
lgd = legend('EMU+proj heuristic','SparseMU + proj heuristic','RMU','RCG'); 
lgd.Location='southeast';
xlabel('Iteration','Interpreter','latex');
ylabel('$F - F_\textrm{min}$','Interpreter','latex');
set(gca,'FontSize',19);
     subplot(122)
     semilogy(t0,F0-Fmin+eps,'k-x','linewidth',5),hold on,
     semilogy(t1,F1-Fmin+eps,'b:x','linewidth',2)
     semilogy(t2,F2-Fmin+eps,'c-x','linewidth',2)
     semilogy(t3,F3-Fmin+eps,'m-x','linewidth',2)
     grid on,axis tight
     xlabel('Time (sec)','Interpreter','latex');
     set(gca,'FontSize',19);
%% AUC
[auc,best_idx] = getAUC(F0,t0,F1,t1,F2,t2,F3,t3);