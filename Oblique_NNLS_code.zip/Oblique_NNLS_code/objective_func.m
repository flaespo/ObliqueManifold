function [F,f,g] = objective_func(M,W,H,lambda)
f        = 0.5*norm(M-W*H,'fro')^2;

sqrH     = sqrt(H); % elementwise square root
norm_12H = sum(sqrH(:)); % sum all elements
g        = lambda*norm_12H;

F        = f + g;
end