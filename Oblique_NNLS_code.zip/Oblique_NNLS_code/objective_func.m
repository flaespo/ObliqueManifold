function [F,f,g] = objective_func(M,W,H,lambda)
f        = 0.5*norm(M-W*H,'fro')^2;
g        = lambda*sum(sqrt(H(:)));
F        = f + g;
end