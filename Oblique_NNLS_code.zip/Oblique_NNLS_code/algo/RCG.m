function [H, F, t, f, g] = RCG(M, W, Hini, lam, maxiter,maxtime)
WtM  = W'*M; % constant outside loop
WtW  = W'*W; % constant outside loop
 F = zeros(1, maxiter);
 f = F;
 g = F;
% Initialize
B = sqrt(Hini); % H = B⊙B
B = B ./ vecnorm(B, 2, 1); % Project to oblique manifold (column-wise L1 norm = 1)
H = B .* B;
grad_prev = zeros(size(B));
Xi_prev   = grad_prev;
    
    % Parameters for Wolfe conditions (following the paper)
    c1         = 0.0001;  
    c2         = 0.9;   
    alpha_init = 1; % Initial step size

totalTime = 0; % Cumulative time
for k = 1 : maxiter
iterStart = tic; % Start timer for this iteration
        
        % Compute Riemannian gradient grad_L(B)
        grad = compute_grad(B, WtW, WtM, lam);
        
        % Compute conjugate direction Xi_k
        if k == 1
            Xi = -grad;
        else
            beta = compute_beta(grad, grad_prev, Xi_prev, B, B_prev);
            Xi   = -grad + beta * vector_transport(Xi_prev, B_prev, B);
        end
        
        % Wolfe line search for alpha
        alpha = wolfe_line_search(B, Xi, grad, W, M, WtW, WtM, lam, c1, c2, alpha_init);
        
        % Retraction update
        B_new  = retraction(B, alpha * Xi);
        
        % Update variables
        B_prev    = B;
        grad_prev = grad;
        Xi_prev   = Xi;
        B         = B_new;
        H         = B .* B;
totalTime = totalTime + toc(iterStart); % Update cumulative time
t(k)      = totalTime; % Record time up to this iteration      
[F(k),f(k),g(k)] = objective_func(M, W, H, lam); % not timed
if (t(k)>=maxtime) break; end
end%end for loop

checkFeasibility(H)
%% chop F,f,g if early stop
minlength = min([numel(t) numel(F)]);
F(minlength+1:end)=[];
f(minlength+1:end)=[];
g(minlength+1:end)=[];
t(minlength+1:end)=[];
end%EOF
%%
function grad = compute_grad(B, WtW, WtM, lam)
 % Euclidean gradient
 grad_euclid = 2*(WtW*(B .* B) -WtM) .* B + (lam/2)*sign(B);
 % Project onto tangent space of OB
 grad = grad_euclid - B .* sum(B .* grad_euclid, 1);
end
%% Hybrid beta (Dai-Yuan + Hestenes-Stiefel)
function beta = compute_beta(grad, grad_prev, Xi_prev, B, B_prev)
%   grad      - current gradient at B
%   grad_prev - previous gradient at B_prev
%   Xi_prev   - previous search direction
%   B         - current point on manifold
%   B_prev    - previous point on manifold

% Transport previous Xi to current tangent space
transported_Xi = vector_transport(Xi_prev, B_prev, B);

% Transport previous gradient to current tangent space
transported_grad = vector_transport(grad_prev, B_prev, B);
    
% Compute y_k = grad_k - transported(grad_{k-1})
y_k = grad - transported_grad;
    
% Calculate both beta variants
beta_HS = (grad(:)' * y_k(:)) / (transported_Xi(:)' * y_k(:) + eps);
beta_DY = (grad(:)' * grad(:)) / (transported_Xi(:)' * y_k(:) + eps);
beta    = max(0, min(beta_HS, beta_DY));
end
%% Vector transport on oblique manifold
function transported = vector_transport(Xi, B_old, B_new)
  V           = B_old + Xi;
  transported = Xi - (V * diag(sum(V .* B_new, 1))) ./ vecnorm(V, 2, 1).^2;
end
%% Retraction onto oblique manifold
function B = retraction(B, Xi)
  V = B + Xi;
  B = V ./ vecnorm(V, 2, 1);
end
%% Wolfe conditions line search
function alpha = wolfe_line_search(B, Xi, grad, W, M, WtW, WtM, lambda, c1, c2, alpha_init)
alpha       = alpha_init;
max_ls_iter = 5; % in the paper 
    
    % Current function value
    H = B .* B;
    f_current = 0.5*norm(M-W*H,'fro')^2 + lambda*sum(H(:).^0.5);
    
    % Directional derivative
    g_Xi = sum(grad .* Xi, 'all');
    
    for ls_iter = 1:max_ls_iter
        % Trial point
        B_trial = retraction(B, alpha * Xi);
        H_trial = B_trial .* B_trial;
        
        % Trial function value
        f_trial = 0.5*norm(M - W*H_trial,'fro')^2 + lambda*sum(H_trial(:).^0.5);
        
        % gradient at trial point
        grad_trial = compute_grad(B_trial, WtW, WtM, lambda);
        
        % Check Armijo condition (sufficient decrease)
        if f_trial > f_current + c1 * alpha * g_Xi
            alpha = alpha * 0.5;
            continue;
        end
        
        % Check curvature condition
        g_Xi_trial = sum(grad_trial .* vector_transport(Xi, B, B_trial), 'all');
        if g_Xi_trial < c2 * g_Xi
            alpha = alpha * 1.5;
            continue;
        end
   
        return;
    end    
% If line search fails
alpha = 0;
end