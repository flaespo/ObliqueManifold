function [H,F,t,f,g, Astore] = RMU(M,W,Hini,lam, maxiter,maxtime)
% minimize (1/2)||M-WH||_F^2 + lambda || H ||_{1/2}^{1/2} 
%        s.t.   H >=0,   H sum-to-1
% using Riemannain Multiplicative Update
WtM  = W'*M; % constant outside loop
WtW  = W'*W; % constant outside loop
lam2 = lam/2; 
 % Initialize variables
 A = sqrt(Hini);
 F = zeros(1, maxiter);
 f = F;
 g = F;

totalTime = 0; % Cumulative time
for k = 1 : maxiter
iterStart = tic; % Start timer for this iteration
  % Precompute
  A_sq   = A.^2;       % H = A.^2
  WtWH   = WtW * A_sq; % r x n
  WtM_A  = WtM .* A;   % r x n
  
  % Column sums
  diag_vec_1 = sum(A .* WtM_A, 1);   % 1 x n
  diag_vec_2 = sum(WtWH .* A, 1);    % 1 x n
  diag_vec_3 = sum(A .* sign(A),1);  % 1 x n  could skip if A>=0
  
  % Gradients
  gradPos = 2*(WtWH .* A + A .* diag_vec_1) + lam2*sign(A);
  gradNeg = 2*(WtM_A + A .* diag_vec_2) + lam2*A .* diag_vec_3;
  grad    = gradPos - gradNeg;
  
  % Step size
  alpha = A ./ gradPos;
  Z     = -alpha .* grad;
  
  % Retraction
  AZ= A+Z;
  A = AZ ./ vecnorm(AZ,2,1); 
  A = max(A, eps); % Safeguard (prevents blow-up from 1/min(A))

totalTime = totalTime + toc(iterStart); % Update cumulative time
t(k)      = totalTime; % Record time up to this iteration      
[F(k),f(k),g(k)] = objective_func(M, W, A.*A, lam); % not timed

%{
Astore(:,:,k) = A;
subplot(141),plot(f),xlim([1 maxiter])
subplot(142),plot(g),xlim([1 maxiter])
subplot(143)
maxA(k) = 1/max(A(:));
minA(k) = 1/min(A(:));
plot(maxA),xlim([1 maxiter])
subplot(144)
plot(minA),xlim([1 maxiter])
drawnow
%}
if (t(k)>=maxtime) break; end
end%end for loop
%% output H
H = A.*A;
H = H./sum(H,1);
%% chop F,f,g if early stop
minlength = min([numel(t) numel(F)]);
F(minlength+1:end)=[];
f(minlength+1:end)=[];
g(minlength+1:end)=[];
t(minlength+1:end)=[];
end%EOF