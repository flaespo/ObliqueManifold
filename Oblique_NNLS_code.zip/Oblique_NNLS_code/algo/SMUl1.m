% Sparse Multiplicative upates (MU) for non-negative matrix factorization with orthogonalization (Orth-NMF).
%    min || V - WH ||_F^2 + lambda*sum(sum(H)),
%    where {V, W, H} >= 0
function [H,F,t,f,g] = SMUl1(M,W,Hini,lam,maxiter,maxtime)
WtM  = W'*M; % constant outside loop
WtW  = W'*W; % constant outside loop
 F = zeros(1, maxiter);
 f = F;
 g = F;

H         = Hini;
totalTime = 0; % Cumulative time
for k = 1 : maxiter
iterStart = tic; % Start timer for this iteration
  H = H .* WtM ./ max(WtW*H+lam,eps);
  H = H ./ (sum(H,1)+eps); % normalize
totalTime = totalTime + toc(iterStart); % Update cumulative time
t(k)      = totalTime; % Record time up to this iteration      
[F(k),f(k),g(k)] = objective_func(M,W,H,lam); % not timed
if (t(k)>=maxtime) break; end
end%endFOR
%% chop F,f,g if early stop
minlength = min([numel(t) numel(F)]);
F(minlength+1:end)=[];
f(minlength+1:end)=[];
g(minlength+1:end)=[];
t(minlength+1:end)=[];
end%EOF