clear; close all; clc;
%[M,r,Wtrue,m,n] = getPines;
[M,r,Wtrue,m,n,Htrue] = getSamson;
%[M,r,Wtrue,m,n] = getJasper;
%mySurf(Htrue);

[~,Hini] = NNDSVD(M,r,0); % Hini not necessarily colum-normalized
Hini     = Hini ./ sum(Hini,1); % normalize
% Compute lambda
lam = 1e-6*norm(M-Wtrue*Hini,'fro')^2 / sum(sqrt(Hini(:)));
% Run algorithms
[H0,F0,t0] = EMUproj(M,Wtrue,Hini,lam, 51, 60);
[H1,F1,t1] = SMUl1  (M,Wtrue,Hini,lam, 51, 60);
[H2,F2,t2] = RMU    (M,Wtrue,Hini,lam, 6, 60);
[H3,F3,t3] = RCG    (M,Wtrue,Hini,lam, 2, 60);
%% Plot objective vs iterations
Fmin = min([min(F0) min(F1) min(F2) min(F3)]); %Fmin = 0;
figure('Position',[100 100 1300 500],'Color','w');
subplot(1,2,1) % vs iterations -------------------
semilogy(F0-Fmin+eps,'k','LineWidth',5), hold on
semilogy(F1-Fmin+eps,'g','LineWidth',2)
semilogy(F2-Fmin+eps,'c','LineWidth',2)  
semilogy(F3-Fmin+eps,'m','LineWidth',2),grid on, axis tight,
legend('EMU+proj','SparseMU+proj','RMU','RCG','Location','southeast','FontSize',14)
xlabel('Iteration','Interpreter','latex','FontSize',20)
ylabel('$F - F_{\min}$','Interpreter','latex','FontSize',20),set(gca,'FontSize',20)
subplot(1,2,2) % vs time -------------------
semilogy(t0,F0-Fmin+eps,'k','LineWidth',5), hold on
semilogy(t1,F1-Fmin+eps,'g','LineWidth',2)
semilogy(t2,F2-Fmin+eps,'c','LineWidth',2)
semilogy(t3,F3-Fmin+eps,'m','LineWidth',2),grid on, axis tight
xlabel('Time (sec)','Interpreter','latex','FontSize',20),set(gca,'FontSize',20)

% AUC comparison
[auc, best_idx] = getAUC(F0,t0, F1,t1, F2,t2, F3,t3)