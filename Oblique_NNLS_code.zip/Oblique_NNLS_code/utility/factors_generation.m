function [A,X] = factors_generation(dims,J,alpha_A,alpha_X,bench)

%% factors
N = length(dims);
    
switch bench 
        
     case 1 % randn
            
            A = max(0,randn(dims(1),J));
            X = max(0,randn(J,dims(2)));                      
     
     case 2 % rand
            
            A = max(0,randn(dims(1),J));
            X = max(0,rand(J,dims(2)));  
            
     case 3 % controlled sparsity and given cond number
                       
            A = sparse_matrix(dims(1), J, alpha_A); %riga originale
           
            X = sparse_matrix(J, dims(2), alpha_X);  %riga originale
             
%              condX = 1.9;
%             [U2,S2,V2]=svd(X);
%             S2(S2~=0)=linspace(condX,1,min(J, dims(2)));
%             X=U2*S2*V2';
%             X=max(0,X);           
     case 4 % real sine signals              
        
            fs = 5*dims(1);  % sampling frequency 
            tmax = (dims(1)-1)/fs;
            t = 0:1/fs:tmax;        
            fo = (dims(1))/5; 
                   
            for j = 1:J
                 phi = (2*pi)/(J+1);
                 A(:,j) = (max(0,sin(2*pi*fo*t + j*phi)))';             
            end
             X = sprand(J, dims(2), alpha_X);%sparse_matrix(J, dims(2), alpha_X);
            
     case 5 % real period gaussian pulses
                           
            for j = 1:J
                
                fs = 5*dims(1);  % sampling frequency 
                tmax = (dims(1)-1)/fs;
                t = 0:1/fs:tmax;  
                phi = (2*pi)/(J+1);                   
                d = [0:1/(fs/50):tmax;sin(2*pi*0.1*(j:(dims(1)-1)/50+j) + j*phi)]';                  
            
                fs = 1e4*dims(1);
                tc = gauspuls('cutoff',dims(1),0.5,[],-40); 
                ta = -tc:1/fs:tc; 
                x = gauspuls(ta,dims(1),0.5); 
            
                A(:,j) = max(0,circshift(pulstran(t,d,x,fs),5*j,2));                   
                            
            end     % for j 
            %X = sparse_matrix(J, dims(2), alpha_X);
             densityX = 1-alpha_X;%0.7;%sparsityPercentageX / 100; % Density of nonzero elements based on sparsity percentage
             X = sprand(J, dims(2), densityX);
               
    case 6 % Cichocki's signals 
        
         S = load('AC10_art_spectr_noi');
         if J > 10
             disp('Rank should be at most 10');
             return 
         else
            A = (S.X(1:J,:))'; 
         end
         X = sparse_matrix(J, dims(2), alpha_X);      
        
    case 7 % Fixed USGS
        
        Ax = load('USGS_pruned_10_deg.mat');
        Ax = Ax.B;

        J = 4;
        A = Ax(:,[2 31 38 49]); % for USGS (ICAISC 2014)
        [mixed, X] = getSynData(A, 10, 1);
 
   case 8 % USGS with the lowest correlation
        
        Ax = load('USGS_pruned_10_deg.mat');
        Ax = Ax.B;
        A = Ax(:,find(sum(abs(corrcoef(Ax))<0.5,2) > 50));
        J = size(A,2);
        [mixed, X] = getSynData(A, 10, 1);       
        
   case 9 %Microarray
        
        Y = load('Microarray_dataset.mat'); 
        %Y_Golub = Y.Golub(1:5000, 2:39);
        Y_MGUS = Y.MGUS(1:15464, 2:9);
        %YGolub=table2array(Y_Golub);  %k=4
        YMGUS=table2array(Y_MGUS); % k=3
        %[A,X] =nnmf(YGolub,4);
        [A,X] =nnmf(YMGUS,3);

    case 10 % Hyperspectral

     % Ax = load('hyper-20.mat');
     % A = max(0,(Ax.endmembers)');

      Ax = load('USGS_pruned_10_deg.mat');
      Ax = Ax.B;
      A = (Ax(:,[2 31 38 49])); % for USGS (ICAISC 2014)
    
      %  Ax = load('F1_A_9.mat');
       % A = (max(0, Ax.A(:,1:J)));
       % A = (max(0,randn(dims(1),J)));

      Xs = load('F1_S_9.mat');
      for i = 1:size(Xs.S,3)
          Sd(:,:,i) = imresize(Xs.S(:,:,i),0.5);
      end     
      X = max(0,(reshape(Sd(:,:,1:J),[size(Sd,1)*size(Sd,2),J])))';

    case 11 % hipocamps 1

%       Ax = load('USGS_pruned_10_deg.mat');
%       Ax = Ax.B;
%       A = (Ax(:,[2 31 38 49])); % for USGS (ICAISC 2014)

      S = load('AC10_art_spectr_noi');
      if J > 10
         disp('Rank should be at most 10');
         return 
      else
        A = (S.X(1:J,:))'; 
      end              
    
      Xs = load('Ax.mat');
      X_tmp_1 = max(0,Xs.Ax);
      for j = 1:J
          X_tmp(:,:,j) = sum(X_tmp_1(:,:,(5*(j-1)+1):5*j),3);
      end

      for i = 1:size(X_tmp,3)
          Xr(:,:,i) = imresize(X_tmp(:,:,i),0.2);
      end
      X = (reshape(Xr,size(Xr,1)*size(Xr,2),size(Xr,3)))';
       
    case 12 % hipocamps 2

      Ax = load('USGS_pruned_10_deg.mat');
      Ax = Ax.B;
      A = (Ax(:,[2 31 38 49])); % for USGS (ICAISC 2014)
    
      Xs = load('Ax.mat');
      X_tmp_1 = max(0,Xs.Ax);
      for j = 1:J
          X_tmp(:,:,j) = sum(X_tmp_1(:,:,(5*(j-1)+1):5*j),3);
      end

      for i = 1:size(X_tmp,3)
          Xr(:,:,i) = imresize(X_tmp(:,:,i),0.2);
      end
      X = (reshape(Xr,size(Xr,1)*size(Xr,2),size(Xr,3)))';
      
      
    case 13
        % Step 1: Specify the desired conditioning number
        %condA = 1.3070;

        % Step 2: Generate a random sparse matrix with fixed sparsity percentage
        
        %sparsityPercentage = 81.5; % Desired sparsity percentage (e.g., 10%)
        density = 1-alpha_A;%0.2;%0.815;%sparsityPercentage / 100; % Density of nonzero elements based on sparsity percentage
        A = sprand(dims(1), J, density);

        % Step 3: Compute the current conditioning number
        %currentCondNumber = cond(full(A));

        % Step 4: Modify the matrix to approximate the desired conditioning number
        %tolerance = 1e-6; % Tolerance for conditioning number approximation
%         maxIterations = 100; % Maximum number of iterations
%         iteration = 1;
%         while abs(currentCondNumber - condA) > tolerance && iteration <= maxIterations
%             % Apply modifications to the matrix (e.g., scaling rows or columns, adding or removing elements)
%             % Modify the matrix A here based on your specific approach
%              A = sprand(dims(1), J, density);
%             % Recalculate the conditioning number
%             currentCondNumber = cond(full(A));
% 
%             iteration = iteration + 1;
%         end
        
       
        
        % Step 1: Specify the desired conditioning number
        %condX = 2;

        % Step 2: Generate a random sparse matrix with fixed sparsity percentage
        
        %sparsityPercentageX = 90; % Desired sparsity percentage (e.g., 10%)
        densityX = 1-alpha_X;%0.7;%sparsityPercentageX / 100; % Density of nonzero elements based on sparsity percentage
        X = sprand(J, dims(2), densityX);

        % Step 3: Compute the current conditioning number
        %currentCondNumberX = cond(full(X));

        % Step 4: Modify the matrix to approximate the desired conditioning number
        %tolerance = 1e-6; % Tolerance for conditioning number approximation
        %maxIterations = 100; % Maximum number of iterations
%         iteration = 1;
%         while abs(currentCondNumberX - condX) > tolerance && iteration <= maxIterations
%             % Apply modifications to the matrix (e.g., scaling rows or columns, adding or removing elements)
%             % Modify the matrix A here based on your specific approach
%             X = sprand(J, dims(2), densityX);
%             % Recalculate the conditioning number
%             currentCondNumberX = cond(full(X));
% 
%             iteration = iteration + 1;
%         end
%         
     
end % switch
   
end%EOF







function A = sparse_matrix(I,J,sA)
% Mixing matrix
a_row = 1; a_col = 1;
A= rand(I,J).*max(0,sign(rand(I,J)-sA));
while (~isempty(a_row) | ~isempty(a_col)) & (min(size(A)) > 1)
      a_row = find(sum(A>0,2)<2);
      if ~isempty(a_row)
          for i = 1:length(a_row)
              A(a_row(i),ceil(rand(1,2)*J)) = abs(rand(1,2) + eps);
          end
      end
      a_col = find(sum(A>0,1)<2);
      if ~isempty(a_col)
         for i = 1:length(a_col)
             A(ceil(rand(2,1)*I),a_col(i)) = abs(rand(2,1) + eps);
         end
      end
end % while
end%EOF




