function checkFeasibility(H)

% get col sum  
col_sum = sum(H,1);

if any(abs(col_sum - 1) > 1e-6)
    warning('a column of H does not sum to 1');
end
if any(H < -1e-12)
    warning('H has negative entries');
end

end%EOF