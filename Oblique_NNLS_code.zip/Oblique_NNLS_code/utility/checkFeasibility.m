function checkFeasibility(H)

% find any column in H not sum to 1

% get col sum
col_sum = sum(H,1);
if isempty( abs(col_sum-1) > 1e-6 )
 warning('a column of H not sum-to-1');
end

if isempty( H<0)
 warning('an entry of H negative');
end

end%EOF