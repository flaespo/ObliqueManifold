% EMU: minimize (1/2)||M-WH||_F^2 + lambda || H ||_{1/2}^{1/2} 
%        s.t.   H >=0,   H sum-to-1
% using Eq(12) in
%   Hyperspectral Unmixing via L1/2 Sparsity-Constrained Nonnegative Matrix Factorization
%   Yuntao Qian, Sen Jia, Jun Zhou, and Antonio Robles-Kelly,
%   IEEE TRANSACTIONS ON GEOSCIENCE AND REMOTE SENSING, VOL. 49, NO. 11, NOVEMBER 2011
% AND
%   proj onto sum-to-1
function [H,F,t,f,g] = EMU_proj(M,W,Hini,lambda, maxiter, maxtime)
WtM  = W'*M; % constant outside loop
WtW  = W'*W; % constant outside loop
lam2 = lambda/2; 

 F = zeros(1, maxiter);
 f = zeros(1, maxiter);
 g = zeros(1, maxiter);

H         = Hini;
totalTime = 0; % Cumulative time
for k = 1 : maxiter
iterStart = tic; % Start timer for this iteration

 sqrtH = sqrt(H);       % element-wise square root
 H05   = sum(sqrtH(:)); % sum of entries
 H     = H .* (WtM ./ ( WtW*H + lam2*H05 ) ); % Eq(12) in EMU
 H     = H ./ (sum(H,1)+eps); % normalize

totalTime = totalTime + toc(iterStart); % Update cumulative time
t(k)      = totalTime; % Record time up to this iteration      
[F(k),f(k),g(k)] = objective_func(M,W,H,lambda); % not timed
 if t(k) >= maxtime
    break;
 end
end%end for loop

checkFeasibility(H)

% chop F,f,g if early stop
minlength = min([numel(t) numel(F)]);
F(minlength+1:end)=[];
f(minlength+1:end)=[];
g(minlength+1:end)=[];
t(minlength+1:end)=[];
end%EOF