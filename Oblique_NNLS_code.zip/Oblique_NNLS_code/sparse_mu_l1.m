function [H,F,t,f,g] = sparse_mu_l1(M,W,Hini,lam,maxiter,maxtime)
% Sparse Multiplicative upates (MU) for non-negative matrix factorization with orthogonalization (Orth-NMF).
%    min || V - WH ||_F^2 + lambda*sum(sum(H)),
%    where {V, W, H} >= 0
% References
%  D. Lee and S. Seung, "Algorithms for non-negative matrix factorization", 
%  NIPS, 2001.
%
%  J. Eggert and E. Korner, "Sparse coding and NMF", 
%  IEEE International Joint Conference on Neural Networks, 2004.
%
%  M. Schmidt, J. Larsen, and F. Hsiao, "Wind noise reduction using non-negative sparse coding", 
%  IEEE Workshop on Machine Learning for Signal Processing (MLSP), 2007.
WtM  = W'*M; % constant outside loop
WtW  = W'*W; % constant outside loop

 F = zeros(1, maxiter);
 f = zeros(1, maxiter);
 g = zeros(1, maxiter);

H    = Hini;
totalTime = 0; % Cumulative time
for k = 1 : maxiter
iterStart = tic; % Start timer for this iteration

  H = H .* ( WtM ./ max( WtW*H + lam, eps) );
  H = H ./ (sum(H,1)+eps); % normalize

totalTime = totalTime + toc(iterStart); % Update cumulative time
t(k)      = totalTime; % Record time up to this iteration      
[F(k),f(k),g(k)] = objective_func(M,W,H,lam); % not timed
 if t(k) >= maxtime
    break;
 end
end%endFOR

% chop F,f,g if early stop
minlength = min([numel(t) numel(F)]);
F(minlength+1:end)=[];
f(minlength+1:end)=[];
g(minlength+1:end)=[];
t(minlength+1:end)=[];
end%EOF