% minimize (1/2)||M-WH||_F^2 + lambda || H ||_{1/2}^{1/2} 
%        s.t.   H >=0,   H sum-to-1
% using Riemannain Multiplicative Update
function [H,F,t,f,g] = RMU(M,W,Hini,lam, maxiter,maxtime)
WtM  = W'*M; % constant outside loop
WtW  = W'*W; % constant outside loop
lam2 = lam/2; 

 % Initialize variables
 A = sqrt(Hini);
 F = zeros(1, maxiter);
 f = zeros(1, maxiter);
 g = zeros(1, maxiter);

totalTime = 0; % Cumulative time
for k = 1 : maxiter
iterStart = tic; % Start timer for this iteration

       A_sq  = A.*A;  % H = A.^2
       sgnA  = sign(A);
       WtWH  = WtW * A_sq;
       WtM_A = WtM .* A;

  diag_vec_1 = sum(A .* WtM_A, 1); % diag_vec_1 = diag(A'*(WtM.*A)); % sum each column vertically
    
    WtWHA    = WtWH.*A;
    grad_pos = 2*(WtWHA  + A.*diag_vec_1) + lam2*sgnA; % grad_pos = 2* WtWH .* A + lam2*sgnA + 2*A*diag(diag_vec_1);
    
  diag_vec_2 = sum(WtWHA, 1); % diag_vec_2 = diag(A'*(WtWH));
  diag_vec_3 = sum(A .* sgnA, 1); % diag_vec_3 = diag(A'*signA);
    
    grad_neg = 2*(WtM_A + A .* diag_vec_2) + lam2*A .* diag_vec_3; % grad_neg = 2*WtM.*A + 2*A*diag_mat_2 + lam2*A*diag_mat_3;
    
    % Riemannian gradient 
    grad     = grad_pos - grad_neg;
    alpha    = A ./ (grad_pos + eps);
    Z        = -alpha .* grad;
    A_Z      = A + Z;
    diag_vec = sum(A_Z .* A_Z, 1); % diag_vec = diag(A_Z'*A_Z); % sum of squares for each column
    fac      = 1 ./ (sqrt(diag_vec) + eps); % fac = (sqrt(diag_mat)+eps)^(-1);
    A        = A_Z .* fac; % A = A_Z*fac; % column-wise scaling
    
totalTime = totalTime + toc(iterStart); % Update cumulative time
t(k)      = totalTime; % Record time up to this iteration      
[F(k),f(k),g(k)] = objective_func(M, W, A.*A, lam); % not timed
 if t(k) >= maxtime
    break;
 end
end%end for loop

% output H
H = A.*A;
checkFeasibility(H)

% chop F,f,g if early stop
minlength = min([numel(t) numel(F)]);
F(minlength+1:end)=[];
f(minlength+1:end)=[];
g(minlength+1:end)=[];
t(minlength+1:end)=[];
end%EOF
%% verify new code is correct
%{
A = sqrt(Hini);
WtW = W'*W;
WtM = W'*M;
lam2 = lam/2;

A_sq  = A.*A;  % H = A.^2
sgnA = sign(A);
WtWH  = WtW * A_sq;
WtM_A = WtM .* A;

diag_vec_1 = diag(A'*(WtM.*A));
grad_pos = 2* WtWH .* A + lam2*sgnA + 2*A*diag(diag_vec_1);

diag_vec_1b = sum(A .* WtM_A, 1); % sum each column vertically
grad_posb = 2*(WtWH.*A  + A .* diag_vec_1b) + lam2*sgnA;
    
diag_vec_2 = diag(A'*(WtWH));
diag_vec_3 = diag(A'*sgnA);
grad_neg = 2*(WtM.*A) + 2*A*diag(diag_vec_2) + lam2*A*diag(diag_vec_3);

diag_vec_2b = sum(A .* WtWH, 1);
diag_vec_3b = sum(A .* sgnA, 1);
grad_negb = 2*(WtM_A + A .* diag_vec_2b) + lam2*A .* diag_vec_3b;

norm(grad_pos-grad_posb,'fro')
norm(grad_neg-grad_negb,'fro')
%}