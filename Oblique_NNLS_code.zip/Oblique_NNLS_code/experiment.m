clear;close all;clc
%% gen data
m = 50;
n = 100;
r = 3;
sparsity_level_H = 0.5;
kk_max = 100;

ranking = zeros(4,kk_max);
noise_level_sigma = 0.1; % 0 no noise, 0.1 low, 0.3 high

for kk = 1:kk_max
[W_exact,H_exact] = factors_generation([m n],r,0,sparsity_level_H,3);
M                 = W_exact*H_exact + noise_level_sigma*rand(m,n);
%% initialization
[~,Hini] = NNDSVD(M,r,0); % Hini not necessarily colum-normalized
lam      = 0.5*norm(M-W_exact*Hini,'fro')^2 / sum(sum(sqrt(Hini)));
%% Run algo
maxiter = 1e6; % max number of iteration
maxtime = 5;   % max run time
[H0,F0,t0] = EMU_proj    (M,W_exact,Hini,lam, maxiter,maxtime);
[H1,F1,t1] = sparse_mu_l1(M,W_exact,Hini,lam, maxiter,maxtime);
[H2,F2,t2] = RMU         (M,W_exact,Hini,lam, maxiter,maxtime);
[H3,F3,t3] = RCG         (M,W_exact,Hini,lam, maxiter,maxtime);
%% Final values
Fend(1,kk)=F0(end);
Fend(2,kk)=F1(end);
Fend(3,kk)=F2(end);
Fend(4,kk)=F3(end);
Tend(1,kk)=t0(end);
Tend(2,kk)=t1(end);
Tend(3,kk)=t2(end);
Tend(4,kk)=t3(end);
NNZ9(1,kk)=nnz(H0>=1e-9);
NNZ9(2,kk)=nnz(H1>=1e-9);
NNZ9(3,kk)=nnz(H2>=1e-9);
NNZ9(4,kk)=nnz(H3>=1e-9);
auc = getAUC(F0,t0,F1,t1,F2,t2,F3,t3);
[~, ranking(:,kk)] = sort(auc);
kk
end
%% Get mean+-std
mean_methodsF = mean(Fend')';
std_methodsF  = std(Fend')';
fprintf('F_last mean/std: %.4f, %.4f\n', mean_methodsF(1), std_methodsF(1));
fprintf('F_last mean/std: %.4f, %.4f\n', mean_methodsF(2), std_methodsF(2));
fprintf('F_last mean/std: %.4f, %.4f\n', mean_methodsF(3), std_methodsF(3));
fprintf('F_last mean/std: %.4f, %.4f\n', mean_methodsF(4), std_methodsF(4));

mean_methodsT = mean(Tend')';
std_methodsT  = std(Tend')';
fprintf('T_last mean/std: %.4f, %.4f\n', mean_methodsT(1), std_methodsT(1));
fprintf('T_last mean/std: %.4f, %.4f\n', mean_methodsT(2), std_methodsT(2));
fprintf('T_last mean/std: %.4f, %.4f\n', mean_methodsT(3), std_methodsT(3));
fprintf('T_last mean/std: %.4f, %.4f\n', mean_methodsT(4), std_methodsT(4));
%% Get Ranking
counts = zeros(4, 4); % rows: methods, columns: ranks (1st, 2nd, 3rd, 4th)
for trial = 1:kk_max
 for method = 1:4
   rank = ranking(method, trial); % Get rank of method in this trial
   counts(method, rank) = counts(method, rank) + 1; % Increment count
 end
end
disp('Ranking:')
for method = 1:4
 fprintf('Method-%d: %d, %d, %d, %d\n', method, counts(method, 1), counts(method, 2), counts(method, 3), counts(method, 4));
end
%% sparsity
median_methodsNNZ_perc = median(NNZ9')' ./ numel(Hini) * 100;
fprintf('NNZ_last median: %.4f\n', median_methodsNNZ_perc(1));
fprintf('NNZ_last median: %.4f\n', median_methodsNNZ_perc(2));
fprintf('NNZ_last median: %.4f\n', median_methodsNNZ_perc(3));
fprintf('NNZ_last median: %.4f\n', median_methodsNNZ_perc(4));