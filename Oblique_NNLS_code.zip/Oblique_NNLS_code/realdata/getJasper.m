function [M,r,W,m,n] = getJasper
% following https://uk.mathworks.com/help/images/classify-hyperspectral-image-using-sam-metric.html

hcube = hypercube("jasperRidge2_R198.img");
Cube = hcube.DataCube;
for j = 1 : 198
  Slice = Cube(:,:,j);
  M(j,:) = double(Slice(:));
end

% Normalize each band
for j = 1:size(M,1)
    band = M(j,:);
    M(j,:) = (band - min(band)) / (max(band) - min(band));
end


% ignore first band
M(1,:) = [];

% normalize M pixel to 1 max
M = M ./ max(M(:));

[m,n] = size(M);

filenames = ["water.seawater.none.liquid.tir.seafoam.jhu.becknic.spectrum.txt",...
    "vegetation.tree.eucalyptus.maculata.vswir.jpl087.jpl.asd.spectrum.txt",...
    "soil.utisol.hapludult.none.all.87p707.jhu.becknic.spectrum.txt",...
    "soil.mollisol.cryoboroll.none.all.85p4663.jhu.becknic.spectrum.txt",...    
    "manmade.concrete.pavingconcrete.solid.all.0092uuu_cnc.jhu.becknic.spectrum.txt"];
lib = readEcostressSig(filenames);
classNames = [lib.Class];


r = numel(lib); %5
numBands = 198;  % from M
W = zeros(numBands, r);  % 198 x r
for idx = 1:r
    refl = lib(idx).Reflectance(:);  % make column
    len = numel(refl);
    % Resample to 198 points
    W(:,idx) = interp1(linspace(1,len,len), refl, linspace(1,len,numBands), 'linear');
end

% ignore first band
W(1,:) = [];

end%EOF