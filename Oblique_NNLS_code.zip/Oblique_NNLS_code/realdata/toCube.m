function HCube = toCube(H)

[r,n] = size(H);

for j = 1 : r
 HCube(:,:,j) = reshape(H(j,:),sqrt(n),sqrt(n));
end
end