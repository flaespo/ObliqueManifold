function [M,r,W,m,n] = getPines
% Load MATLAB hyperspectral image: Built-in hyperspectral Data
data = load('indian_pines.mat'); 

M3   = data.indian_pines; % size: height × width × bands
W    = data.signatures;   % size: height × width × bands
r    = size(W,2);         % latent rank

M    = reshape(M3, [], size(M3,3))';   % M: bands × pixels

% Set NMF dimension
[m, n] = size(M);          % m = bands, n = pixels
