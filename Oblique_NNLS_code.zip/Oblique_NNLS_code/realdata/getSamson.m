function [M,r,W,m,n,H] = getSamson
load("samson_1.mat");
load("end3.mat");

W = M;
M = V;
H = A;
r = 3;
[m,n] = size(M);
end