function mySurf(H)
r     = size(H,1);
HCube = toCube(H);

figure('Position',[1900 800 1300 500],'Color','w');
for j = 1 : r
 subplot(1,r,j),
 h = surf(HCube(:,:,j),'EdgeColor','none'); axis ij; 
 colormap jet;colorbar;clim([0 1]);
 camlight('headlight'); material shiny;  lighting gouraud;
azimuth   = 1;    % in degrees (horizontal rotation)
elevation = 81;     % in degrees (vertical angle)
view(azimuth, elevation);
colorbar
end

end%EOF