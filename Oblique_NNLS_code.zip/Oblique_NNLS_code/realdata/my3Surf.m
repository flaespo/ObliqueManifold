function my3Surf(H0,H2,H3)
r = size(H0,1);
H0Cube = toCube(H0);
H2Cube = toCube(H2);
H3Cube = toCube(H3);

figure('Position',[1900 800 1300 500],'Color','w');
for j = 1 : r
subplot(3,r,j),
     h = surf(H0Cube(:,:,j),'EdgeColor','none');axis ij; 
     colormap gray;colorbar;%clim([0 1]);
     camlight('headlight'); material shiny;  lighting gouraud;
     azimuth   = 1;    % in degrees (horizontal rotation)
     elevation = 81;     % in degrees (vertical angle)
     view(azimuth, elevation);
subplot(3,r,j+r),
     h = surf(H2Cube(:,:,j),'EdgeColor','none');axis ij; 
     colormap gray;colorbar;%clim([0 1]);
     camlight('headlight'); material shiny;  lighting gouraud;
     azimuth   = 1;    % in degrees (horizontal rotation)
     elevation = 81;     % in degrees (vertical angle)
     view(azimuth, elevation);
subplot(3,r,j+2*r),
     h = surf(H3Cube(:,:,j),'EdgeColor','none');axis ij; 
     colormap gray;colorbar;%clim([0 1]);
     camlight('headlight'); material shiny;  lighting gouraud;
     azimuth   = 1;    % in degrees (horizontal rotation)
     elevation = 81;     % in degrees (vertical angle)
     view(azimuth, elevation);
end%end for

end%EOF