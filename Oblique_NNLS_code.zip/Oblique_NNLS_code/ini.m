clear;close all;clc
rng(42)
addpath('utility/')
addpath('realdata/')
addpath('algo/')